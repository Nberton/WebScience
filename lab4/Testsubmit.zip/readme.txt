Name: Nathan Berton

Media Queries are pretty cool. 

I had trouble getting the grid to play nice with the animation.


resources:
http://api.jquerymobile.com/responsive-grid/
