Name: Nathan Berton


Challenges:
The resolution of the icons from openweathermap was disappointing. Also the structure of the JSON for single
location was rather interesting. The "weather" tag was an array with one element with a bunch of stuff in 
that single element. 


Sources:
http://www.w3schools.com/html/html5_geolocation.asp