Name: Nathan Berton


Personal GitHub repository: https://github.com/Nberton/WebScience

Group Github repository: https://github.com/dmastylo/itws-4200-group/

Group Website Location: http://104.236.238.78:3000/

We are using Github's Issue Tracker which you have access to via Github


Challenges:
Peter's Github hates him. Max also was not present so we are adding him later.



