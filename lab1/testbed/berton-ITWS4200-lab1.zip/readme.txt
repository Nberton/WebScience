Name: Nathan Berton


Challenges:
Remembering how to use foundation and creating round images. The 404 was also a pain to deal with on the
images. 




sources:
http://stackoverflow.com/questions/8244902/count-number-of-divs-inside-a-div
http://stackoverflow.com/questions/9679419/how-to-remove-div-if-count-bigger-than-x-with-jquery
http://bavotasan.com/2011/circular-images-with-css3/
http://stackoverflow.com/questions/22577371/how-to-make-rectangular-image-appear-circular-with-css
http://stackoverflow.com/questions/92720/jquery-javascript-to-replace-broken-images
https://about.twitter.com/press/brand-assets